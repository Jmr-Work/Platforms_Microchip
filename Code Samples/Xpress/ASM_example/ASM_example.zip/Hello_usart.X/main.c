/*
 * File:   main.c
 * Author: 79620edb-cf1f-4d96-96b1-3c186903dfd8@transim.com
 *
 * Created on 2/16/2016 7:44:43 PM UTC
 * "Created in MPLAB Xpress"
 */


#include <xc.h>

void main(void) {
    
    int iteration;
    while(1)
    {
    
    for(iteration = 0; iteration < 1000000 ; iteration++)
    {
        _nop();  //  noting operation    
    }
    
    
    asm("sleep");   // sleep operation
    
    for(iteration = 0; iteration < 1000000 ; iteration++)
    {      
        _nop();  //  noting operation
    }
   
    
    asm("reset");   // reset operation
        
    }
    
    
    return;
}
