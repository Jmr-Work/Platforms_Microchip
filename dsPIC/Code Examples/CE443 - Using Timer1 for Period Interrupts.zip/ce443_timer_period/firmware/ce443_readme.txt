                     Readme File for Code Example:
               CE443 - Using Timer1 for Period Interrupts
               ---------------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------

a. This Code example gives a demonstration of how to use the Timer1 for Period Interrupts .

b. When ever the Timer1 register is equal to the Period Register the Timer1 generates a Interrupt 
   and Toggles the PORTA.1 bit  of the PORTA i:e D4 LED on Explorer 16 .

c. In order to configure the Period Value Configure the PR1 register in the init_timer1.c file.

d. This code examples uses the value of M as 38 and N1 and N2 as 2 so and the External Crystal Frequency as 8 Mhz .

   In Case you are using the Externel Crystal value more then 8 Mhz you have to reconfigure the values of M ,N1,N2 (any one of
   them will also do) so that the Processore runs at or below 40MIPS otherwise the processor will run above 40MIPS and unexpected 
   results may occur.

   Example:

   If using External Crystal of 8Mhz M1=40,N1=N2=2 then Fosc=80 Mhz and Fcy= 40Mhz 
      External Crystal = 12Mhz M1=24,N1=N2=2 then Fosc=74Mhz and Fcy=37Mhz 
e. It is recommended to start thr processor on a clock without PLL and then enter the values to the PLL register and
   then switch to PLL mode . The same is being followed in this code.

f. Init_timer1.c--------For Initialization of Timer1 for Period Interrupt

g. Switch.s-------------For Switching from the non PLL mode to PLL mode with XT mode

h. main.c---------------Main Application running in the code.



2. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and include files(*.c,
        *.s, *.h) and project specific files used in demonstrating the described example. 
b. system_config
		This folder contains the chipset specific configuration code. More specifically it inturn contains a folder called exp16/ 
		which holds configuration files.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 depending on the platform.Each platform folder contain,configuration 
		specific source files.

3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controller

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

5. Revision History :
---------------------
	
	07/01/2010 - Code Example updated for dsPIC33E
	1/03/2014  - Code Example updated for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
	11/19/2014 - Code Example update for Test automation