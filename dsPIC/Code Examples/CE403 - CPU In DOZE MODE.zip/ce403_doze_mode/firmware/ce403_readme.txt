
				Readme File for Code Example:
				CE403 - CPU In DOZE MODE
             ----------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
In this example, CPU is setup in DOZE mode to run at 1/128 of the System Clock. 
Device is initially configured to run at Fcy=60Mhz and then DOZE mode is enabled to run the CPU at 468.75Khz (60M/128).
Check the RA4 pin toggles i.e at a frequency of ~234khz.

extern void setDozeRatio(unsigned int r);
This function sets the required DOZE ratio and enables the DOZE mode

2. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and  include files
	(*.c,*.s,*.h) used in demonstrating the described example. 
b. system_config
		This folder contains all the xxx_config.c file, which contain basic configuration routines and pin-remap code for a specific platform.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506, depending on the platform.Each platform folder contain,
		configuration specific source files.


3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controllers

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for  dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to a dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.


5. Revision History :
---------------------
        04/01/2006 - Initial Release of the Code Example
		01/27/2014 - Code Example updated to new format for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
		11/27/2014 - Code Example updated to TEST_MODE code.
