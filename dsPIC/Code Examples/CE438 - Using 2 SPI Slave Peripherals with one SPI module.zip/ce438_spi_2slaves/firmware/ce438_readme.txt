                     Readme File for Code Example:
               CExxx - Using 2 SPI Slave Peripherals with one SPI module
               ---------------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
This code example shows using the SPI module in conjunction with 2 GPIO pins to communicate with 2 different slave
devices.  The concept is that the GPIO are the slave selects for the individual devices, but the SCL, SDI and SDO are shared between the two processors.  
This is also scalable up to n devices, where your only limitation is the bus bandwidth on the SPI bus and the number of GPIO lines at your disposal.

Slave Select1 ---|			          |---------------------------------------------------------
		 |________________________________|

Slave Select2 ---------------------------------------------| 			           |-----------------
		                                           |_______________________________|

SCLK   xxxxxxxxxx |-| |-| |-| |-| |-| |-| |-| |-| xxxxxxxxxx |-| |-| |-| |-| |-| |-| |-| |-| xxxxxxxxxx
       xxxxxxxxxx_| |_| |_| |_| |_| |_| |_| |_| |_xxxxxxxxxx_| |_| |_| |_| |_| |_| |_| |_| |_xxxxxxxxxx

SDO    xxxxxxxxxx d7  d6  d5  d4  d3  d2  d1  d0  xxxxxxxxxx d7  d6  d5  d4  d3  d2  d1  d0  xxxxxxxxxx

The code alternates between sending data from one device to another and mixed.

2. Folder Contents:
-------------------

a. src
        This folder contains all the C, Assembler source files and  include files
	(*.c,*.s,*.h) used in demonstrating the described example. 


3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dsPIC33EP512GM710 controller

Note :- The PPS configuration in the source files changes with the device being used. The user is advised
to refer the datasheet and use the appropriate values for RPINR/RPOR registers for proper operation.

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for any dsPIC33E device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to a dsPIC33E device of
        your choice by using the following menu option:
        MPLAB X>>Project Properties>>Device

        b. Provide the correct device linker script and header file for your
        device. Device linker scripts and header files are available in your
        MPLAB� xc16 installation folder under:
        Device Linker Script-
                YourDrive:>Program Files\Microchip\xc16\support\gld
        Device C Header file-
                YourDrive:>Program Files\Microchip\xc16\support\h
        Device ASM Include file-
                YourDrive:>Program Files\Microchip\xc16\support\inc

        c. Provide the appropriate path to your xc16 support file locations
        using the menu option:
        MPLAB X>>Project Properties>>XC16

        d. Chose the development board applicable to your device. Some options
        are provided below:


        e. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        f. Download the hex file into the device and run.

5. Revision History :
---------------------
	07/01/2010 - Code Example updated for dsPIC33E
