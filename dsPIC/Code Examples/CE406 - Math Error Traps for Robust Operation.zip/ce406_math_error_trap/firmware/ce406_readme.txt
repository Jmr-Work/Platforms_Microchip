
                              Readme File for Code Example:
                        CE406 - Math Error Traps for Robust Operation
                        ----------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
Microchip's 16-bit dsPIC� Digital Signal Controllers feature an on-chip mechanism to detect software errors and 
take corrective action. Specifically, the ability to detect arithmetic (math) errors is provided by means of 
automatic Math Error Trap detection.

Math errors may be caused by one of the following:

a. Divide by Zero

b. Accumulator A overflow (bit 31 destroyed)

c. Accumulator B Overflow (bit 31 destroyed)

d. Catastrophic overflow of Accumulator A (bit 39 destroyed)

e. Catastrophic overflow of Accumulator B (bit 39 destroyed)

f. Accumulator Shift count error

If the application defines an Math Error Trap service routine (trap handler), the processor will vector to the 
trap handler when it detects a math error.

NOTE: This routine also estimates the instruction that caused the math error trap to occur by examining the 
PC value that is stored in the stack prior to entering the Math Error Trap. Since the instruction that causes 
divide by zero error to occur is not executed, the stacked PC points to the offending instruction. 
However, the instructions that cause accumulator overflows to occur will be executed prior to the trap being caused. 
So the stacked PC will point to the instruction after the offending instruction. 
Thus, the estimation routines differ slightly for the Divide by Zero error and the Accumulator Overflow errors. 
It should also be noted that since this trap routine is written in C the estimation of the stacked PC will 
depend on the compiler optimization level set up for this file. In the trap routine presented here, a comiler 
optimization level of 0 is assumed for this file.

2. Folder Contents:
-------------------
a. src
        This folder contains all the C, Assembler source files and include files(*.c,
        *.s, *.h) used in demonstrating the described example. 
b. system_config
		This folder contains the chipset specific configuration code. More specifically it inturn contains a folder called exp16/ 
		which holds configuration files.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 depending on the platform.Each platform folder contain,configuration 
		specific source files.

3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controller

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.5. Revision History :
---------------------
        04/01/2006 - Initial Release of the Code Example
		07/01/2010 - Code Example updated for dsPIC33E
		12/13/2013 - Code Example updated for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
