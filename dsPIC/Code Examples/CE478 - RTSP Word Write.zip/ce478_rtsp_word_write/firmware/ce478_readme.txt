
				Readme File for Code Example:
              CE478 - Flash RTSP code example 
             ----------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
In this example, a page of Flash memory (512 instructions or 8 rows of 64 instruction) is read first.
Then the page is erased fully. One row of the page is modified and written back to the flash. Then, a few words
in the already programmed flash are modified and read back to verify the modification.

Following RTSP Application Program Interface (APIs) are used to perform the operation.

// Flash Memory is organised into ROWs of 64 instructions or 192 bytes
// RTSP allows the user to erase a PAGE of memory which consists of EIGHT ROWs (512 instructions or 1536byts) at a time.
// RTSP allows the user to program a ROW (64 instructions or 192 bytes) at a time


2. Folder Contents:
-------------------

a. firmware
        This folder contains all the C, Assembler source files and  include files
	(*.c,*.s,*.h) used in demonstrating the described example. 
b. system_config
		This folder contains all the xxx_config.c file, which contain basic configuration routines and pin-remap code for a specific platform.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506, depending on the platform.Each platform folder contain,
		configuration specific source files.


3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controllers

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for  dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to a dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

5. Revision History :
---------------------
	02/07/2014 - Code Example updated to new format for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
	11/21/2014 - Code Example updated for adding the Test automation