
                              Readme File for Code Example:
                        CE405 - Address Error Traps for Easy Debugging
                        ----------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
Microchip's 16-bit dsPIC� Digital Signal Controllers feature an on-chip mechanism to detect software errors and 
take corrective action. Specifically, the ability to detect memory addressing errors is provided by means of 
automatic Address Error Trap detection. Memory addressing errors may be caused by one of the following:

a. A misaligned data word fetch is attempted. This condition occurs when an instruction performs a word 
   access with the LSb of the effective address set to �1�. The dsPIC33E CPU requires all word accesses to 
   be aligned to an even address boundary.

b. A bit manipulation instruction using the Indirect Addressing mode with the LSb of the effective address set to �1�.

c. A data fetch from unimplemented data address space is attempted.

d. Execution of a �BRA #literal� instruction or a �GOTO #literal� instruction, where literal is an unimplemented 
   program memory address.

e. Executing instructions after modifying the PC to point to unimplemented program memory addresses. 
   The PC may be modified by loading a value into the stack and executing a RETURN instruction.

If the application defines an Address Error Trap service routine (trap handler), the processor will vector to the 
trap handler when it detects an Address Error trap.


Note:
The user should note that the MPLAB� xc16 C compiler will not intentionally generate any instructions that cause 
an address error trap to occur. The compiler/assembler will also detect address error instances in code whenever possible.

2. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and include files(*.c,
        *.s, *.h) and project specific files used in demonstrating the described example. 
b. system_config
		This folder contains the chipset specific configuration code. More specifically it inturn contains a folder called exp16/ 
		which holds configuration files.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 depending on the platform.Each platform folder contain,configuration 
		specific source files.

3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controller

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

5. Revision History :
---------------------
        04/01/2006 - Initial Release of the Code Example
	07/01/2010 - Code Example updated for dsPIC33E
	12/05/2013 - Code Example updated for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
