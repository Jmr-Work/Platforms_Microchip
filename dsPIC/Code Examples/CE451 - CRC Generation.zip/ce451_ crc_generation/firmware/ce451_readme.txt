                     Readme File for Code Example:
						CE451 - CRC Generation
               ---------------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------

In this code examples, CRC module is used to generate CRC for input data.


CRC_Calc_ChecksumByte()
This function calculates the CRC Checksum for the array of bytes provided by the user based on the polynomial 
set in the CRCXORH and CRCXORL registers

The initial CRC value in the CRCWDATL register depends on the CRC polynomial being used in the code. 

The CRC-CCITT polynomial requires 0x84CF to be loaded as the initial value in CRCWDATL register. 
The CRC16 and CRC32 polynomials require 0x0000 to be loaded as the initial value in CRCWDATL register. 


2. Folder Contents:
-------------------

a. firmware
        This folder contains all the C, Assembler source files and  include files
	(*.c,*.s,*.h) used in demonstrating the described example. 
b. system_config
		This folder contains all the xxx_config.c file, which contain basic configuration routines and pin-remap code for a specific platform.
c. exp16/
		This folder contains the platform specific files.


3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controllers

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for  dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to a dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

5. Revision History :
---------------------
			01/31/2014 - Code Example updated to new format for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
			11/06/2014 - Code Example was modified for autoval and some update was made.
			