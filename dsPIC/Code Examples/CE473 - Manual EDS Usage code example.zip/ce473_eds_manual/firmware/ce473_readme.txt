
				Readme File for Code Example:
              CE473 - Manual EDS Usage code example 
             -----------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History

1. Code Example Description:
----------------------------
This code example demonstrates how a mixture of automatic (compiler-managed) and manual
(user-managed) Extended Data Space (EDS) variables can be defined and used in an application.
In this example, 3 data arrays are defined to be stored in Extended Data Space (EDS):
'm1', 'm2' and 'm'. Of these, 'm' has been defined as a compiler-managed EDS variable, i.e. 
the EDS registers are automatically managed by the compiler without requiring the user code
to modify or save/restore the contents of the EDS registers. 'm1' and 'm2' have been defined
as EDS variables that the user application needs to manage manually (i.e. the compiler will not
modify or save/restore the value of the DSRPAG registers). In addition, a non-EDS array 'x' has
been defined. The code example performs an element-by-element Vector Multiplication of the 
'm1', 'm2' and 'm' arrays with the array 'x', and stores the products in arrays 'sum1', 'sum2' 
and 'sum', respectively. The arrays 'sum1' and 'sum2' have been defined as EDS variables 
that the user application needs to manage manually (i.e. the user needs to manually modify 
and save/restore the DSWPAG register in this case), whereas 'sum' has been defined as a
compiler-managed EDS variable.   

2. Folder Contents:
-------------------

a. firmware
        This folder contains all the C, Assembler source files and  include files
	(*.c,*.s,*.h) used in demonstrating the described example. 
b. system_config
		This folder contains all the xxx_config.c file, which contain basic configuration routines and pin-remap code for a specific platform.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506, depending on the platform.Each platform folder contain,
		configuration specific source files.


3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controllers

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for  dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to a dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

5. Revision History :
---------------------
	05/20/2011 - Initial Release of the Code Example
	01/28/2014 - Code Example updated to new format for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
	11/05/2014 - TEST Mode code was added during automation testing of Code examples