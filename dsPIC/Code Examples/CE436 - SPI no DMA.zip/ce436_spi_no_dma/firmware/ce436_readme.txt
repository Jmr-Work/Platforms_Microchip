                     Readme File for Code Example:
						CExxx -- SPI no DMA
               ---------------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
This code example shows using a single SPI module in conjunction with a GPIO to generate an SPI communication that will work with most SPI Slave devices.

Slave Select  ---------------------------------------------| 			           |-----------------
		                                           |_______________________________|

SCLK   xxxxxxxxxx |-| |-| |-| |-| |-| |-| |-| |-| xxxxxxxxxx |-| |-| |-| |-| |-| |-| |-| |-| xxxxxxxxxx
       xxxxxxxxxx_| |_| |_| |_| |_| |_| |_| |_| |_xxxxxxxxxx_| |_| |_| |_| |_| |_| |_| |_| |_xxxxxxxxxx

SDO    xxxxxxxxxx d7  d6  d5  d4  d3  d2  d1  d0  xxxxxxxxxx d7  d6  d5  d4  d3  d2  d1  d0  xxxxxxxxxx

The code sends from 00h through FFh and then cycles through again.  A delay was added to permit catching the output on a logic analyzer easier.

Externally Connect for testing:
-------------------------------
RF7 & RF8 on Expl16 board for dspic33ep256GP506 PIM
RF7 & RF8 on Expl16 board for dspic33ep512gm710 PIM
RF2 & RF3 on Expl16 board for dspic33ep512mu810 PIM


2. Folder Contents:
-------------------

a. firmware
        This folder contains all the C, Assembler source files and include files(*.c,
        *.s, *.h) and project specific files used in demonstrating the described example. 
b. system_config
		This folder contains the chipset specific configuration code. More specifically it inturn contains a folder called exp16/ 
		which holds configuration files.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 depending on the platform.Each platform folder contain,configuration 
		specific source files.


3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controller


4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.
5. Revision History :
---------------------
	07/01/2010 - Code Example updated for dsPIC33E
	1/03/2014  - Code Example updated for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506