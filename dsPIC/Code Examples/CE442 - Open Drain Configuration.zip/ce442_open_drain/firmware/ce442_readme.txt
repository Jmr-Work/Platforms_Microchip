                     Readme File for Code Example:
               CE442 - Open Drain Configuration
               ---------------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Output verification
3. Folder Contents
4. Suggested Development Resources
5. Reconfiguring the project for a different dsPIC33E device
6. Revision History


1. Code Example Description:
----------------------------
This code shows an example of setting the Open Drain Configuration for a generic I/O Port.
The open-drain feature allows the generation of outputs higher than VDD
(e.g., 5V on a 5V tolerant pin)by using external pull-up resistors.
An external Pull up resistor should be connected for the port configured as
open drain output.
Open drain output is default high because of the external pull up resistor.
In software the port configured as open drain is set to low during initialization
and set as high when Switch S3 is pressed.
Refer ce419_i2c_eeprom code example for a peripheral configured as open drain output.

2. Output verification:
----------------------------
  Monitor the open drain output port in the Oscilloscope .
  Output will be low when Switch S3 is released and high when S3 is pressed.

3. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and include files(*.c,
        *.s, *.h) and project specific files used in demonstrating the described example. 
b. system_config
		This folder contains the chipset specific configuration code. More specifically it inturn contains a folder called exp16/ 
		which holds configuration files.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 depending on the platform.Each platform folder contain,configuration 
		specific source files.

4. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controller

5. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

6. Revision History :
---------------------
	07/01/2010 - Code Example updated for dsPIC33E
	3/24/2014  - Code Example updated for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.