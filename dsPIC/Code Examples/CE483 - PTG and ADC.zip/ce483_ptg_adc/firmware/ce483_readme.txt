								Readme File for Code Example:
               CE483 - Generating phase shifted PWMs using Output Compare modules and Peripheral trigger generator(PTG)
               -------------------------------------------------------------------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
In this example, PWM1 is setup to produce pwm frequency of 20KHz (50us period). 

PWM1 is configured in Edge aligned ,complementary PWM mode and PTPER PTPER register provides 
timing for this PWM generator.SYNCO output is enabled and is mapped to RP55.


PTG Sequencer ,from the start of PWM ON time waits for 15 us, and then generate ADC triggers 
to sample analog signal 6 times.After generating every ADC trigger, sequencer is made to  wait
for ADC conversion to complete ,before generating next trigger.At the end generates a PTG Interrupt 
to process the acquired signal samples.

RC6 is toggled in ADC interrupt,and also in PTG Interrupt 0.This is done for understanding.Sample
timing diagram is shown below.
                   

                   .                                                                                 .
                   .                                                                                 .
                   .<----------------------------------------------Period = 50us------------------- >.
                    ______________________________________                                            _______
                   |                                      |                                          |                          	                                                                   |          |
PWM1H    	___|<--5us-->                             |__________________________________________|
              ___                                            ______________________________________                                                              
                 |                                          |                                      |          		                                      
PWM1L    	 |__________________________________________|<-------10us------>                   |_________
                  _                                                                                 _
                 | |                                                                               | |                        	                                                                   |          |
SYNCO(RP55)   ___| |_______________________________________________________________________________| |________

                  ______________________________________        ______        _______        __                      
                 |                                      |      |      |      |       |      |  |                                                                            	                                                                   |          |
RC6           ___|                                      |______|      |______|       |______|  |______________



This can be reconfigured according to application requirement.


2. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and  include files
	(*.c,*.s,*.h) used in demonstrating the described example. 
b. system_config
		This folder contains all the xxx_config.c file, which contain basic configuration routines and pin-remap code for a specific platform.
c. exp16/
		This folder contains various folders like dspic33ep512gm710, depending on the platform.Each platform can folder contain,configuration specific 
		source files.

3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dsPIC33EP512GM710 controller

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for  dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to a dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

5. Revision History :
---------------------
       Initial Release of the Code Example
	   01/31/2014 - Code Example updated to new format for dspic33ep512gm710