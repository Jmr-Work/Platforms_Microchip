
				Readme File for Code Example:
              CE422 - ADC Alternate Sampling
             ----------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------

In this example, Timer 3 is setup to time-out every 125 microseconds (8Khz Rate). 
As a result, the module will stop sampling and trigger a A/D conversion on every Timer3 time-out, i.e., Ts=125us. 

ADC is configured in 10bit mode to alternatively sample AN4/AN5 analog input on Timer 3 interrupt. 
It will take TWO Timer3 Timeout period to sample AN4 first and then AN5.

ADC module clock time period is configured as Tad=Tcy*(ADCS+1)= (1/60M)*64 = 1.06us (625Khz). 
Hence the conversion time for 10-bit A/D Conversion Time Tc=12*Tad = 12.72us

DMA is used to sort and transfer the converted data to DMA RAM. DMA is configured in ping-pong mode 
and it transfers 16samples of each of the TWO analog inputs and generates interrupt. 


DMA channel 0 is configured in ping-pong mode to move the converted data from ADC to DMA RAM 
on every sample/convert sequence. 
First, DMA uses DMA0STA base address to store the ADC samples and it generates interrupt 
after transfering (TWO x 16 samples = 32 samples).
Next, DMA uses DMA0STB base address to store the ADC samples and it generates interrupt
after transfer (TWO x 16 samples = 32 samples).
Above process repeats continuously. 

void __attribute__((__interrupt__)) _DMA0Interrupt(void);
DMA interrupt service routine, moves the data from DMA buffer to ADC signal buffer 

Timer time outs at 60M/(4999+1) = 12000 Hz.
DMA interrupt @ 12K/32=  375 Hz.
I/O pin toggles at 375/2= 187 Hz.

RA4 pin is toggled in ISR, hence it will be toggling at ~ 187Hz



2. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and include files(*.c,
        *.s, *.h) and project specific files used in demonstrating the described example. 
b. system_config
		This folder contains the chipset specific configuration code. More specifically it inturn contains a folder called exp16/ 
		which holds configuration files.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 depending on the platform.Each platform folder contain,configuration 
		specific source files.

3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controller

Note :- The PPS configuration in the source files changes with the device being used. The user is advised
to refer the datasheet and use the appropriate values for RPINR/RPOR registers for proper operation.

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

        f. Download the hex file into the device and run.

5. Revision History :
---------------------
        07/09/2006 - Initial Release of the Code Example
		07/01/2010 - Code Example updated for dsPIC33E
		1/21/2014  - Code Example updated for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
		11/13/2014 - Test_MODE code added for automation testing.