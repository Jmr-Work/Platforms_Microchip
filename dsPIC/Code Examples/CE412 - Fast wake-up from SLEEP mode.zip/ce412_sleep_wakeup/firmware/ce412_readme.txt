
                              Readme File for Code Example:
                        CE412 - Fast wake-up from SLEEP mode
                        ------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
Microchip's 16-bit dsPIC� Digital Signal Controllers are capable of resuming regular operation after waking up from a 
low-power mode, for example, SLEEP mode, within 10 microseconds. Additionally, within 30 microseconds of waking up from 
SLEEP mode, the device can operate at its highest speed of operation.To wake up from SLEEP in 10 microseconds or less, 
the device should be made to operate off the Fast RC (FRC) Oscillator prior to entering SLEEP mode. To wake up from SLEEP
and operate at maximum speed in 30 microseconds or lesser, the device should be made to operate off the Fast RC (FRC)
Oscillator with the PLL enabled, prior to entering SLEEP mode. This is possible because the PLL locks in 20 microseconds 
and the FRC oscillator, unlike a crystal oscillator has no start-up time. The POR circuit in the device inserts a small 
delay of 10 microseconds to ensure all bias circuits have stabilized on a power-up event.

The attached code example demonstrates this capability using external interrupt pin, INT1. Using this example, the user
can measure the time elapsed between a falling edge on the INT1 pin and a rising edge on any pin on Port D. 
The time measured will be the time to wake up from SLEEP using an FRC oscillator plus the time taken by the PLL to lock plus
the 5*Tcy consistent interrupt service routine entry time.The attached code example will
configure the PLLFBD register which provides a factor �M�, by which the input to the VCO is multiplied.
For devices that do not feature the FRCxPLL option, the FOSC configuration register will be set up to use the FRC oscillator on power-up.

The benefit offered by dsPIC33E devices to low-power applications is not only a low-power SLEEP mode option but also the 
option to wake-up from SLEEP in a short amount of time and execute code at the highest speed possible.

2. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and  include files
	(*.c,*.s,*.h) used in demonstrating the described example. 
b. system_config
		This folder contains all the xxx_config.c file, which contain basic configuration routines and pin-remap code for a specific platform.
c. exp16/
		This folder contains various folders like dspic33epxxxgm710/dspic33epxxxMU810/dspic33epxxxgp506, depending on the platform.Each platform folder contain,configuration 
		specific source files.

3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controller

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

5. Revision History :
---------------------
        04/01/2006 - Initial Release of the Code Example
		07/01/2010 - Code Example updated for dsPIC33E
		01/17/2014 - Code example updated to new format for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
