                     Readme File for Code Example:
               CExxx -- PMP
               ---------------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
This code example aims to demonstrate the basic initialisation and operation of the Parallel Master Port (PMP) module.
It also demonstrates to communicate with the LCD module using PMP and display a set of characters on the LCD pannel
The PMP module is configured in the Master Mode.


Set the I/O ports as digital ports.


mLDCInit()
This function will initialise the LCDinit pointer to sets LCDState mchine to _uLCDstate = 2


TimerInit()
This function will enable to run the Timer


BannerStart()
This function will enable to Setup the banner processing
The following events are performed in this function
-  Check if the LCD is busy
-  Set the Cursor to the starting point
-  Initialise the banner number and banner length


In the While loop the following events follow.

LCDProcessEvents()
This is a state machine to issue commands and data to LCD. Must be called periodically to make LCD message processing.
The communication with the LCD module is enabled through the PMP module.
This function Initialises the LCD function + Processes a series of LCD events.

-  Initialises the LCD function.
   Open the PMP module for communication with LCD ( Case2) 
   complete a set of events to initialise the LCD from (Case 64 to case 71)
   Clear the LCD state machine i.e (_uLCDstate = 0)


TimerIsOverflowEvent()
Only on timer Overflow the BannerProcessEvents is processed


BannerProcessEvents()
-  Display the Banner array 
   Pick the character to be displayed from the banner pointer
   Prepare the character for display
   Select the first line or second line for display.
After the display of banner array the control moves back to the while loop.

The banner is displayed sequentially.


2. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and include files(*.c,
        *.s, *.h) and project specific files used in demonstrating the described example. 
b. system_config
		This folder contains the chipset specific configuration code. More specifically it inturn contains a folder called exp16/ 
		which holds configuration files.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810 depending on the platform.Each platform folder contain,configuration 
		specific source files.

3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810 controller


4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

5. Revision History :
---------------------
        
        02/12/2014 - Code Example updated for dspic33ep512gm710/dspic33ep512mu810
		11/19/2014 - Code Example updated for TEST_MODE Code inclusion