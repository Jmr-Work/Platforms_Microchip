
                              Readme File for Code Example:
                        CE407 - Stack Error Traps for Easy Debugging
                        ----------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History

1. Description:
---------------
Microchip's 16-bit dsPIC� Digital Signal Controllers feature a software stack, i.e., the stack is part of general 
purpose RAM. PUSH and POP instructions use the W15 register as a stack pointer to place variables on to the 
top of stack location or to unload variables from the top of stack location in RAM. 

The CPU also features a mechanism to detect software errors and take corrective action.

Specifically, the ability to detect over-utilization or under-utilization of the Stack is provided by 
means of automatic Stack Error Trap detection. Stack Errors may be caused by one of the following:

a. Stack Overflow - W15 is greater than the SPLIM register
b. Stack Underflow - W15 is lesser than the base address of RAM

If the application defines a Stack Error Trap service routine (trap handler), the processor will vector 
to the trap handler when it detects a Stack Error trap.



Note:
The user should note that the MPLAB� xc16 C compiler will not intentionally generate any instructions 
that cause a stack error trap to occur.


2. Folder Contents:
-------------------

a. firmware
        This folder contains all the C, Assembler source files and  include files
	(*.c,*.s,*.h) used in demonstrating the described example. 
b. system_config
		This folder contains all the xxx_config.c file, which contain basic configuration routines and pin-remap code for a specific platform.
c. exp16/
		This folder contains various folders like dspic33epxxxgm710/dspic33epxxxMU810/dspic33epxxxgp506, depending on the platform.Each platform folder contain,configuration 
		specific source files.

3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controller

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.
		
5. Revision History :
---------------------
        04/01/2006 - Initial Release of the Code Example
		07/01/2010 - Code Example updated for dsPIC33E
		12/18/2013 - Code example updated to new format for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
		02/03/2015 - Code example updated to add TEST_MODE code