
                              Readme File for Code Example:
             CE408 - Oscillator failure traps and Fail-safe Clock Monitoring
             ---------------------------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
Microchip's 16-bit dsPIC� Digital Signal Controllers feature an on-chip mechanism to detect oscillator/clock failures.
In addition, the processor features the ability to continue code execution using an internal Fast RC oscillator.

The attached code example demonstrates:
a. How the Fail-Safe Clock Monitor module may be enabled via config macros.
b. How to write an effective Oscillator Failure trap service routine.

In this example, the device is configured to operate off an external canned oscillator running via the PLL. 
The code in the main.c file simply toggles a general purpose I/O port pin,RA7.
The user may place an oscilloscope probe on RA7 to verify the frequency at which the it is being toggled.
The user may then simply disconnect the canned oscillator from the board or ground it's output to simulate a clock failure.
The device continues to operate using the Internal FRC oscillator. 
The CPU vectors to the Oscillator Failure trap and clears the trap condition via a special write sequence 
to the OSCCONL register. 

Further, a software flag is set if the PLL was found to be out-of-lock.

Note: In this project clock switching and clock monitoring has been enabled. MPLAB IDE will warn the user 
to perform a POR on the board in this case. This is being done because when clock switching has been enabled, 
the device uses the clock active prior to the last MCLR reset event (specified in the COSC bits in OSCCON register) 
rather than the clock settings specified by the FOSC fuse. In order for the device to use the clock source specified 
by the FOSC fuse, a POR reset event must take place.

2. Folder Contents:
-------------------
a. src
        This folder contains all the C, Assembler source files and include files(*.c,
        *.s, *.h) used in demonstrating the described example. 
b. system_config
		This folder contains the chipset specific configuration code. More specifically it inturn contains a folder called exp16/ 
		which holds configuration files.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 depending on the platform.Each platform folder contain,configuration 
		specific source files.

3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controller

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.5. Revision History :

5. Revision History :
---------------------
        04/01/2006 - Initial Release of the Code Example
		07/01/2010 - Code Example updated for dsPIC33E
		12/19/2013 - Code Example updated for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506