
				Readme File for Code Example:
              CE402 - ADC Conversion in Sleep mode 
             ----------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
In this example, ADC is set up to convert AIN5 using CH0 S/H and ADC is operating using its internal RC osc. 
Start of conversion is issued in the background loop and device enters sleep mode immediately after that. 

When the ADC conversion is completed in sleep mode, it wakes up the device and enters ADC ISR.


void initAdc1(void);
ADC CH0 is set-up to covert AIN5 in 10-bit mode. ADC is configured to next sample data immediately after the conversion.
But the start of conversion is issued manually in the background loop.

void _ADC1Interrupt()
Device enters the ADC ISR after waking up from sleep mode. ADC result is read in the ISR and PORTA (RA4) pin is toggled.


2. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and include files(*.c,
        *.s, *.h) and project specific files used in demonstrating the described example. 
b. system_config
		This folder contains the chip-set specific configuration code. More specifically it in-turn contains a folder called exp16/ 
		which holds configuration files.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 depending on the platform.Each platform folder contain,configuration 
		specific source files.


3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controller

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

        f. Download the hex file into the device and run.


5. Revision History :
---------------------
        04/01/2006 - Initial Release of the Code Example
		07/01/2010 - Code Example updated for dsPIC33E
		1/21/2014  - Code Example updated for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
		11/13/2014 - TEST_MODE code added for test automation