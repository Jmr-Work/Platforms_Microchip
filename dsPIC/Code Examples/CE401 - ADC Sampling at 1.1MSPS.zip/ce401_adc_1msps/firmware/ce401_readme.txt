
				Readme File for Code Example:
              CE401 - ADC Sampling at 1.1MSPS 
             ----------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
In this example, ADC is set up to convert AIN0 using CH0 and CH1 sample/hold in 10-bit sequential mode 
at 1.1MHz throughput rate. ADC clock is configured at 13.3Mhz or Tad=75ns
ADC Conversion Time for 10-bit conversion is Tc=12*Tab =  900ns (1.1MHz).

void initAdc1(void);
ADC CH0 and CH1 S/H is set-up to covert AIN0 in 10-bit mode. ADC is configured to next sample data immediately after the conversion.
So, ADC keeps conversion data through CH0/CH1 S/H alternatively. Effective conversion rate is 1.1Mhz

void initDma0(void);
DMA channel 0 is configured in ping-pong mode to move the converted data from ADC to DMA RAM on every sample/convert sequence. 
It generates interrupt after every 16 sample transfer. 

void __attribute__((__interrupt__)) _DMA0Interrupt(void);
DMA interrupt service routine, moves the data from DMA buffer to ADC signal buffer and collects 256 samples.

The Toggle frequency of one pulse should be around 240us(micro second), if the operating clock frequency at 40Mhz.
Short AN0/AN1 with +3.3v to get analog signal for sampling. These values should be approximately around 0x7FXXX when checked in the bufferA/bufferB in the code.

2. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and  include files
	(*.c,*.s,*.h) used in demonstrating the described example. 
b. system_config
		This folder contains all the xxx_config.c file, which contain basic configuration routines and pin-remap code for a specific platform.
c. exp16/
		This folder contains various folders like dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506, depending on the platform.Each platform folder contain,
		configuration specific source files.

3. Suggested Development Resources:
-----------------------------------
         a. Explorer 16 Demo board with dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 controllers

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for  dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLABX� IDE to a dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

5. Revision History :
---------------------
        04/01/2006 - Initial Release of the Code Example
		07/01/2010 - Code Example updated for dsPIC33E
		02/13/2014 - Code Example updated to new format for dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506
		11/13/2014 - TEST_MODE code added for test automation