#ifndef _CDT_H_
#define _CDT_H_

#include <stdint.h>

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wattributes"
#pragma GCC diagnostic ignored "-Wunknown-pragmas"

#define __prog__

extern void __builtin_write_OSCCONL(uint8_t val);

#endif /* _CDT_H_ */

